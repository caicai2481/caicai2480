#### 介绍
B站视频的文档资料柜，
java学习从入门到找工作必备

#### 一定要关注公众号，超多福利
公众号：itnanls
![avatar](https://itnanls.cn/assets/img/team/gzh.jpg)

#### 官网：[www.itnanls.cn](https://www.itnanls.cn) 
打造最干净的java自学网，收费咨询和答疑群：咨询微信 itnanls。500元每周六答疑。
从零到就业的视频和资料统统免费。
大学的同学们，如果有时间好好学习吧！

#### B站主页
https://www.bilibili.com/video/BV1YV411r762

